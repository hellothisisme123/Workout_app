Cleaned Code
