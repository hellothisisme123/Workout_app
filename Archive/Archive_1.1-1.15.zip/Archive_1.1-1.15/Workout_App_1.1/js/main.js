var Global_checklist_count = 0; //a global count starting at 0 of every checklist

class Checklist { //Checklist class
    constructor(/*id_selector,*/
                id,
                checklist,
                height,
                width,
                left,
                top,
                item_count
    ) {
        /*this.id_selector = document.getElementById(id);*/
        this.id = id; 
        this.checklist = checklist;
        this.height = height;
        this.width = width;
        this.left = left;
        this.top = top;
        this.item_count = item_count;
    }
    
    spawn() { //spawns a checklist
        console.log("spawn"); //logs spawn

        this.checklist = document.getElementById("checklists").appendChild(document.createElement('div'));  //this.checklist is the actual checklist div within the #checklists div. this line spawns the div
        this.id = `checklist_${Global_checklist_count}`; //sets the this.id to the id so that the id can be set and used

        this.checklist = this.checklist.setAttribute("id", this.id); //gives the checklist its id to be more easily manipulatable
        Global_checklist_count++; //ticks the count up 1
        
        //this.id_selector.clientHeight = `${this.height}px`;
        //this.id_selector.clientWidth = `${this.width}px`;
    }

    check_Box(box_number) {
        if (box_number == 1) {
            
        }
    }

    
}

const checklist = new Checklist(5, null, 100, 100, 50, 50, 5); //spawns a checklist from the class as an object

console.log(checklist); //logs the checklist we just spawned
checklist.spawn();  //spawns a checklist
