var Global_checklist_count = 0; //a global count starting at 0 of every checklist
let checklists_all = document.querySelectorAll(".checklist");
let last_item_checklist_id_selectors_array;
let state_management_id_selector = document.querySelectorAll("#state_management");
let state_managemend_only_on_first_checklist = true;
let z_index_top_layer = 1000;

class Checklist { //Checklist class
    constructor(/*id_selector,*/
                resize_range,                               // 1
                id,                                         // 2
                checklist,                                  // 3
                height,                                     // 4
                width,                                      // 5
                left,                                       // 6
                top,                                        // 7
                item_count,                                 // 8
                client_rect,                                // 9
                Default_node_type,                          // 10
                checklist_selector,                         // 11
                checklist_id_selectors_array,               // 12
                moveing_the_div,                            // 13
                selected_div_for_moving,                    // 14
                moveing_x_offset_from_div_to_mouse,         // 15
                moveing_y_offset_from_div_to_mouse,         // 16
                div_y_screen_offset,                        // 17
                mouse_down_event_event_info,                // 18
                initial_y_offset_top,                       // 19
                combined_height_of_all_previous_divs_within_checklists,
                resizing_no_movement
                
                //id_selector
        ) {
        /*this.id_selector = document.getElementById(id);*/
        this.resize_range = resize_range;                       // 1
        this.id = id;                                           // 2                                
        this.checklist = checklist;                             // 3
        this.height = height;                                   // 4
        this.width = width;                                     // 4
        this.left = left;                                       // 6
        this.top = top;                                         // 7
        this.item_count = item_count;                           // 8
        this.client_rect = client_rect;                         // 9
        this.Default_node_type = Default_node_type;             // 10
        this.checklist_selector = checklist_selector;           // 12
        this.checklist_id_selectors_array = [];                 // 13
        this.moveing_the_div = false;                           // 14
        this.selected_div_for_moving = selected_div_for_moving; // 15
        this.moveing_x_offset_from_div_to_mouse = moveing_x_offset_from_div_to_mouse;
        this.moveing_y_offset_from_div_to_mouse = moveing_y_offset_from_div_to_mouse;
        this.div_y_screen_offset = div_y_screen_offset;
        this.mouse_down_event_event_info = mouse_down_event_event_info;
        this.initial_y_offset_top = initial_y_offset_top;
        this.combined_height_of_all_previous_divs_within_checklists = 0;
        this.resizing_no_movement = resizing_no_movement;
        
        
    }
    
    spawn() { //spawns a checklist
        //console.log(checklist); //logs spawn
        last_item_checklist_id_selectors_array = this.checklist_id_selectors_array[this.checklist_id_selectors_array.length - 1];

        
        this.checklist = document.getElementById("checklists").appendChild(document.createElement('div'));  //this.checklist is the actual checklist div within the #checklists div. this line spawns the div
        this.id = `checklist_${Global_checklist_count}`; //sets the this.id to the id so that the id can be set and used
        //this.checklist_id_selectors_array.push(this.id); 

        this.checklist = this.checklist.setAttribute("id", this.id); //gives the checklist its id to be more easily manipulatable
        
        Global_checklist_count++; //ticks the count up 1



        this.checklist_selector = document.getElementById(this.id); //creates a selector for the div
        this.checklist_selector.style.width = `${this.width}px`; //sets width
        this.checklist_selector.style.height = `${this.height}px`;  //sets width
        this.client_rect = this.checklist_selector.getBoundingClientRect(); //sets the boudning box of the div
        this.checklist_selector.classList.add("checklist"); //styles the checklist with the checklist class
        //console.log(this.client_rect);
        checklists_all = document.querySelectorAll(".checklist"); //selector for every checklist
        // this.checklist_selector.setAttribute("data-class");
        //this.checklist_selector.setAttribute("onresize", `checklist${Global_checklist_count}.on_resize_prevent_moving()`); //runs on resize
        //checklist.resize()

        //positions the div in selected position
        this.checklist_selector.style.top = `${this.top}px`;
        this.checklist_selector.style.left = `${this.left}px`;

        //positions the div in selected size
        this.checklist_selector.style.height = `${this.height}px`;
        this.checklist_selector.style.width = `${this.width}px`;
        


        //\/\/\/\_/--- default node types ---\_/\/\/\/\\

        //left_tutorial
        if (this.Default_node_type == "left_tutorial") {
            let h1_selector;
            let ul_selector;
            let li_selector;
            let dumbbell_image_selector;

            console.log("left_tutorial_spawned line 61 to display class");
            //spawns title h1 in checklist
            this.checklist_selector.appendChild(document.createElement('h1'));
            h1_selector = this.checklist_selector.childNodes[0];
            //console.log(`h1_selector:${h1_selector}`);
            h1_selector.classList.add("checklist_title");
            h1_selector.innerHTML = "Lorem ipsum<br>dolor<br>sit consectetur";

            //spawns br
            this.checklist_selector.appendChild(document.createElement('br'));


            //spawns ul for bullet list
            this.checklist_selector.appendChild(document.createElement('ul'));
            ul_selector = this.checklist_selector.childNodes[2];
            ul_selector.classList.add("checklist_bulleted_list");
            //console.log(`ul_selector:${ul_selector}`);


            //spawns li in bullet list
            ul_selector.appendChild(document.createElement('li'));
            li_selector = ul_selector.childNodes;
            //console.log(`li_selector:${li_selector}`);
            li_selector[0].classList.add("checklist_bullet_point");
            li_selector[0].innerHTML = "Lorem";

            //spawns li in bullet list
            ul_selector.appendChild(document.createElement('li'));
            li_selector = ul_selector.childNodes;
            //console.log(`li_selector:${li_selector}`);
            li_selector[1].classList.add("checklist_bullet_point");
            li_selector[1].innerHTML = "Lorem";


            //spawns li in bullet list
            ul_selector.appendChild(document.createElement('li'));
            li_selector = ul_selector.childNodes;
            //console.log(`li_selector:${li_selector}`);
            li_selector[2].classList.add("checklist_bullet_point");
            li_selector[2].innerHTML = "Lorem";


            //spawns li in bullet list
            ul_selector.appendChild(document.createElement('li'));
            li_selector = ul_selector.childNodes;
            //console.log(`li_selector:${li_selector}`);
            li_selector[3].classList.add("checklist_bullet_point");
            li_selector[3].innerHTML = "Lorem";


            //spawns li in bullet list
            ul_selector.appendChild(document.createElement('li'));
            li_selector = ul_selector.childNodes;
            //console.log(`li_selector:${li_selector}`);
            li_selector[4].classList.add("checklist_bullet_point");
            li_selector[4].innerHTML = "Lorem";


            //spawns svg in checklist
            this.checklist_selector.appendChild(document.createElement('img'));
            dumbbell_image_selector = this.checklist_selector.childNodes[3];
            //console.log(svg_selector);
            dumbbell_image_selector.setAttribute("src", "production/images/dumbell.png");
            dumbbell_image_selector.setAttribute("id",  "dumbbell_image_selector");
        }
        
        //middle_tutorial
        if (this.Default_node_type == "middle_tutorial") {
            console.log("middle_tutorial_spawned line 61 to display class");

        }
        
        //right_tutorial
        if (this.Default_node_type == "right_tutorial") {
            console.log("right_tutorial_spawned line 61 to display class");

        }









        checklist.move();
    }

    /*on_resize_prevent_moving() {
        console.log("on_resize_prevent_moving()");
        this.resizing_no_movement = true;
    }*/

    move(/*mouse_down_only_once=true*/) {
        checklists_all.forEach(checklist => {
            /*checklist.addEventListener('resize', (resize_event) => {
                console.log("on_resize_prevent_moving()");
                this.resizing_no_movement = true;
            });*/
            
            checklist.addEventListener('mousedown', (mouse_click_event) => {
                //console.log(mouse_click_event.target);
                this.selected_div_for_moving = mouse_click_event.target; //selector for the target of the mouse keydown
                
                if ( //if in the bottom right corner of the div
                mouse_click_event.offsetX > this.selected_div_for_moving.clientWidth - this.resize_range &&
                mouse_click_event.offsetX < this.selected_div_for_moving.clientWidth + this.resize_range &&
                mouse_click_event.offsetY < this.selected_div_for_moving.clientHeight + this.resize_range &&
                mouse_click_event.offsetY > this.selected_div_for_moving.clientHeight - this.resize_range
                ) {
                    //console.log("resize");
                    this.resizing_no_movement = true; //prevents movement so you can instead resize
                }
                //console.log(mouse_click_event);


                //this.resizing_no_movement = true;
                if (!this.resizing_no_movement) { //if the variable is false then you are moving and not resizing
                    this.moveing_the_div = true; //sets movement of the div to true
                } else return 
                
                this.moveing_x_offset_from_div_to_mouse = mouse_click_event.layerX; //the offset so the user grabs the div at the right spot for x
                //this.mouse_down_event_event_info = mouse_click_event;
                
                
                /*if (mouse_down_only_once == true) {
                    this.initial_y_offset_top = mouse_click_event.target.offsetTop;
                    mouse_down_only_once = false;
                }*/
                
                this.moveing_y_offset_from_div_to_top = mouse_click_event.layerY// + this.combined_height_of_all_previous_divs_within_checklists/*this.mouse_down_event_event_info.target.offsetTop*/;
                //the offset so the user grabs the div at the right spot for y along with some old code
                

                //attempt at making the grabbed div z index appear on the top
                /*z_index_top_layer += 100;
                this.checklist_selector.style.zIndex = z_index_top_layer;
                // = parseInt(this.checklist_selector.style.zIndex) + 100;
                console.log(this.checklist_selector.style.zIndex);*/
                 
                 



                //this.selected_div_for_moving.parendElement.childNodes.length;
                /*this.combined_height_of_all_previous_divs_within_checklists = 0;
                for (let i = 0; i < this.selected_div_for_moving.parentElement.childNodes.length - 1; i++) {
                    //const element = array[i];
                    this.combined_height_of_all_previous_divs_within_checklists = parseInt(this.selected_div_for_moving.parentElement.childNodes[i].style.height);
                    
                    console.log(this.combined_height_of_all_previous_divs_within_checklists);
                }*/
                //console.log();

                /*// this.selected_div_for_moving.parentElement.childNodes.forEach( children_height_combined => {
                //         this.combined_height_of_all_previous_divs_within_checklists += ;
                // });
                
                for (let index = 0, iend = 10000; index < iend; index++) {   
                    if (this.selected_div_for_moving.parentElement.childNodes[index] == undefined) {
                        iend = 0;
                    } else if (this.selected_div_for_moving.parentElement.childNodes[index] != undefined) {
                        this.combined_height_of_all_previous_divs_within_checklists = this.combined_height_of_all_previous_divs_within_checklists + this.selected_div_for_moving.parentElement.childNodes[index].clientHeight;
                        console.log(this.combined_height_of_all_previous_divs_within_checklists);
                        //console.log(this.selected_div_for_moving.parentElement.childNodes[index].clientHeight);
                    }
                    //this.combined_height_of_all_previous_divs_within_checklists += this.selected_div_for_moving.parentElement.childNodes
                }*/
                
            }, {capture: true});


            window.addEventListener('mouseup', (mouse_click_event) => {
                //console.log(mouse_click_event.target);
                this.moveing_the_div = false;
                this.resizing_no_movement = false;
                //on mouseup it stops resizing and movement of div
            });

            window.addEventListener('mousemove', (mouse_move_event) => {
                //console.log(mouse_move_event);
                
                if (this.moveing_the_div == true) { //when you are moving the div
                    //console.log(this.selected_div_for_moving);
                    //console.log(mouse_move_event);
                    this.selected_div_for_moving.style.left = `${parseInt(mouse_move_event.clientX) - parseInt(this.moveing_x_offset_from_div_to_mouse)}px`; // sets the left value of the div to follow the mouse
                }

                if (this.moveing_the_div == true) { //when you are moving the div
                    //console.log(this.selected_div_for_moving);
                    //console.log(mouse_move_event);
                    
                    this.selected_div_for_moving.style.top = `${parseInt(mouse_move_event.clientY) - this.moveing_y_offset_from_div_to_top}px` //sets tge top value of the div to follow the mouse
                    //this.moveing_y_offset_from_div_to_mouse = 

                    //this.selected_div_for_moving.style.top = `${asdas}`;
                    //console.log(mouse_move_event);
                }
            });

            // checklist.addEventListener('resize', (resize_event) => {
            //     this.moveing_the_div = false;
            // });
        });
    }

    /*resize() {
        //checklist_selector is the selector for a checklist
        //resize_range

        checklists_all.forEach(checklist => {
            
            checklist.addEventListener('mousemove', (mouse_movement_Event) => {
                console.log(mouse_movement_Event);
                if (
                    mouse_movement_Event.offsetX > mouse_movement_Event.target.offsetLeft - this.resize_range &&
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft + this.resize_range 
                    ||
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft - this.resize_range &&
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft - this.resize_range
                ) {
                
                }
            
            });
        });
    }

        /*checklists_all.forEach(checklist => {
            checklist.addEventListener('mouseover', (e) => {
                //if () {
                    //e.target.classList.add("horizontal_resize_cursor");
                //}
            });

            checklist.addEventListener('mouseout', (event, Notepad_y_resizable, Notepad_x_resizable) => {
                //event.target.classList.remove("horizontal_resize_cursor");
                //console.log(selected_notepad_mouseaway);
                //document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                //document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
            });

            checklist.addEventListener('mousemove', (mouse_movement_Event, Notepad_x_resizable=false, Notepad_y_resizable=false) => {
                if (
                    mouse_movement_Event.layerX > 0 - this.resize_range &&
                    mouse_movement_Event.layerX < this.resize_range
                    ||
                    mouse_movement_Event.layerX > this.width - this.resize_range &&
                    mouse_movement_Event.layerX < this.width + this.resize_range
                ) {
                    Notepad_x_resizable = true;
                    mouse_movement_Event.target.classList.remove("corner_resize_cursor_left_bottom");
                    mouse_movement_Event.target.classList.add("horizontal_resize_cursor");
                    
                    
                    document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                } else {
                    //if (Notepad_x_resizable) {
                        Notepad_x_resizable = false;
                        
                        document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                        //console.log("Notepad_x_resizable = false;");
                    //}
                    mouse_movement_Event.target.classList.remove("horizontal_resize_cursor");
                }



                if (
                    mouse_movement_Event.layerY > 0 - this.resize_range &&
                    mouse_movement_Event.layerY < this.resize_range
                    ||
                    mouse_movement_Event.layerY > this.width - this.resize_range &&
                    mouse_movement_Event.layerY < this.width + this.resize_range
                ) {
                    Notepad_y_resizable = true;
                    mouse_movement_Event.target.classList.remove("corner_resize_cursor_left_bottom");
                    mouse_movement_Event.target.classList.add("vertical_resize_cursor");
                    
                    document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
                    //console.log("Notepad_y_resizable = true;");
                } else {
                    //if (Notepad_y_resizable) {
                        Notepad_y_resizable = false;
                        
                        document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
                        //console.log("Notepad_y_resizable = false;");
                    //}
                    //Notepad_y_resizable
                    mouse_movement_Event.target.classList.remove("vertical_resize_cursor");
                }
                //console.log(mouse_movement_Event);



                if (Notepad_x_resizable && 
                    Notepad_y_resizable// &&
                    //mouse_movement_Event.left
                    ) {
                    mouse_movement_Event.target.classList.remove("vertical_resize_cursor");
                    mouse_movement_Event.target.classList.add("corner_resize_cursor_left_bottom");
                }
            });

            checklist.addEventListener('mousedown', (mouse_click_event, Notepad_x_resizable, Notepad_y_resizable) => {
                //console.log(mouse_click_event.target)
                if (mouse_click_event.target)    
                    if (Notepad_x_resizable) {
                        Notepad_X_resizeing = true;
                    
                        console.log("Notepad_X_resizeing = true;");
                    } else if (Notepad_y_resizable) {
                        Notepad_y_resizeing = true;
                        console.log("Notepad_y_resizeing = true;");
                    }
            });

            checklist.addEventListener('mouseup', (mouse_click_event, Notepad_X_resizeing, Notepad_y_resizeing) => {
                if (Notepad_X_resizeing) {
                Notepad_X_resizeing = false;
                console.log("Notepad_X_resizeing = false;")
                } else if (Notepad_y_resizeing) {
                Notepad_y_resizeing = false;
                console.log();
                }
            });
            
            
        });
    
    
    check_Box(box_number) {
        if (box_number == 1) {
            
        }
    }*/
                                          //                top
                                          //           left 
}                                         //      width
                                          //height   
const checklist  = new Checklist(20, 5, null, 600, 325, 250, 250, 5, null, "left_tutorial"); //spawns a checklist from the class as an object
const checklist2 = new Checklist(20, 5, null, 250, 350, 730, 600, 5, null, "middle_tutorial");
const checklist3 = new Checklist(20, 5, null, 125, 150, 755, 430, 5, null, "right_tutorial");



//console.log(checklist); //logs the checklist we just spawned
//setTimeout(() => {
    checklist.spawn( );  //spawns a checklist
    checklist2.spawn();
    checklist3.spawn();
    
//}, 1000);


// function addCursor(e){
//     e.target.classList.add("horizontal_resize_cursor");
// }