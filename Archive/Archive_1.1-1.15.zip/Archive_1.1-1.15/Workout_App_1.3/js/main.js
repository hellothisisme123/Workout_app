var Global_checklist_count = 0; //a global count starting at 0 of every checklist
let checklists_all = document.querySelectorAll(".checklist");
let last_item_checklist_id_selectors_array;
let state_management_id_selector = document.querySelectorAll("#state_management");
let state_managemend_only_on_first_checklist = true;

class Checklist { //Checklist class
    constructor(/*id_selector,*/
                resize_range,
                id,
                checklist,
                height,
                width,
                left,
                top,
                item_count,
                client_rect,
                checklist_selector,
                checklist_id_selectors_array
                //id_selector
        ) {
        /*this.id_selector = document.getElementById(id);*/
        this.resize_range = resize_range;
        this.id = id; 
        this.checklist = checklist;
        this.height = height;
        this.width = width;
        this.left = left;
        this.top = top;
        this.item_count = item_count;
        this.client_rect = client_rect;
        this.checklist_selector = checklist_selector;
        this.checklist_id_selectors_array = [];
        
    }
    
    spawn() { //spawns a checklist
        console.log(checklist); //logs spawn
        last_item_checklist_id_selectors_array = this.checklist_id_selectors_array[this.checklist_id_selectors_array.length - 1];

        
        this.checklist = document.getElementById("checklists").appendChild(document.createElement('div'));  //this.checklist is the actual checklist div within the #checklists div. this line spawns the div
        this.id = `checklist_${Global_checklist_count}`; //sets the this.id to the id so that the id can be set and used
        this.checklist_id_selectors_array.push(this.id);

        this.checklist = this.checklist.setAttribute("id", this.id); //gives the checklist its id to be more easily manipulatable
        Global_checklist_count++; //ticks the count up 1



        this.checklist_selector = document.getElementById(this.id); //creates a selector for the div
        this.checklist_selector.style.width = `${this.width}px`; //sets width
        this.checklist_selector.style.height = `${this.height}px`;  //sets width
        this.client_rect = this.checklist_selector.getBoundingClientRect(); //sets the boudning box of the div
        this.checklist_selector.classList.add("checklist"); //styles the checklist with the checklist class
        //console.log(this.client_rect);
        checklists_all = document.querySelectorAll(".checklist");

        //checklist.resize()
        checklist.move()
    }

    move() {
        checklists_all.forEach(checklist => {
            checklist.addEventListener('mousedown', (mouse_click_event) => {
                console.log(mouse_click_event.target);
                if (mouse_click_event.target == true) {


                }
            });


            checklist.addEventListener('mouseup', (mouse_click_event) => {
                console.log(mouse_click_event.target);
                if (mouse_click_event.target == true) {


                }
            });
        });
    }

    /*resize() {
        //checklist_selector is the selector for a checklist
        //resize_range

        checklists_all.forEach(checklist => {
            
            checklist.addEventListener('mousemove', (mouse_movement_Event) => {
                console.log(mouse_movement_Event);
                if (
                    mouse_movement_Event.offsetX > mouse_movement_Event.target.offsetLeft - this.resize_range &&
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft + this.resize_range 
                    ||
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft - this.resize_range &&
                    mouse_movement_Event.offsetX < mouse_movement_Event.target.offsetLeft - this.resize_range
                ) {
                
                }
            
            });
        });
    }

        /*checklists_all.forEach(checklist => {
            checklist.addEventListener('mouseover', (e) => {
                //if () {
                    //e.target.classList.add("horizontal_resize_cursor");
                //}
            });

            checklist.addEventListener('mouseout', (event, Notepad_y_resizable, Notepad_x_resizable) => {
                //event.target.classList.remove("horizontal_resize_cursor");
                //console.log(selected_notepad_mouseaway);
                //document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                //document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
            });

            checklist.addEventListener('mousemove', (mouse_movement_Event, Notepad_x_resizable=false, Notepad_y_resizable=false) => {
                if (
                    mouse_movement_Event.layerX > 0 - this.resize_range &&
                    mouse_movement_Event.layerX < this.resize_range
                    ||
                    mouse_movement_Event.layerX > this.width - this.resize_range &&
                    mouse_movement_Event.layerX < this.width + this.resize_range
                ) {
                    Notepad_x_resizable = true;
                    mouse_movement_Event.target.classList.remove("corner_resize_cursor_left_bottom");
                    mouse_movement_Event.target.classList.add("horizontal_resize_cursor");
                    
                    
                    document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                } else {
                    //if (Notepad_x_resizable) {
                        Notepad_x_resizable = false;
                        
                        document.getElementById('1_console_item').innerHTML = `Notepad_x_resizeable:${Notepad_x_resizable}`;
                        //console.log("Notepad_x_resizable = false;");
                    //}
                    mouse_movement_Event.target.classList.remove("horizontal_resize_cursor");
                }



                if (
                    mouse_movement_Event.layerY > 0 - this.resize_range &&
                    mouse_movement_Event.layerY < this.resize_range
                    ||
                    mouse_movement_Event.layerY > this.width - this.resize_range &&
                    mouse_movement_Event.layerY < this.width + this.resize_range
                ) {
                    Notepad_y_resizable = true;
                    mouse_movement_Event.target.classList.remove("corner_resize_cursor_left_bottom");
                    mouse_movement_Event.target.classList.add("vertical_resize_cursor");
                    
                    document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
                    //console.log("Notepad_y_resizable = true;");
                } else {
                    //if (Notepad_y_resizable) {
                        Notepad_y_resizable = false;
                        
                        document.getElementById('2_console_item').innerHTML = `Notepad_y_resizeable:${Notepad_y_resizable}`;
                        //console.log("Notepad_y_resizable = false;");
                    //}
                    //Notepad_y_resizable
                    mouse_movement_Event.target.classList.remove("vertical_resize_cursor");
                }
                //console.log(mouse_movement_Event);



                if (Notepad_x_resizable && 
                    Notepad_y_resizable// &&
                    //mouse_movement_Event.left
                    ) {
                    mouse_movement_Event.target.classList.remove("vertical_resize_cursor");
                    mouse_movement_Event.target.classList.add("corner_resize_cursor_left_bottom");
                }
            });

            checklist.addEventListener('mousedown', (mouse_click_event, Notepad_x_resizable, Notepad_y_resizable) => {
                //console.log(mouse_click_event.target)
                if (mouse_click_event.target)    
                    if (Notepad_x_resizable) {
                        Notepad_X_resizeing = true;
                    
                        console.log("Notepad_X_resizeing = true;");
                    } else if (Notepad_y_resizable) {
                        Notepad_y_resizeing = true;
                        console.log("Notepad_y_resizeing = true;");
                    }
            });

            checklist.addEventListener('mouseup', (mouse_click_event, Notepad_X_resizeing, Notepad_y_resizeing) => {
                if (Notepad_X_resizeing) {
                Notepad_X_resizeing = false;
                console.log("Notepad_X_resizeing = false;")
                } else if (Notepad_y_resizeing) {
                Notepad_y_resizeing = false;
                console.log();
                }
            });
            
            
        });
    
    
    check_Box(box_number) {
        if (box_number == 1) {
            
        }
    }*/

    
}

const checklist = new Checklist(5, 5, null, 100, 100, 50, 50, 5, null); //spawns a checklist from the class as an object
const checklist2 = new Checklist(5, 5, null, 100, 100, 50, 50, 5, null);



//console.log(checklist); //logs the checklist we just spawned
checklist.spawn();  //spawns a checklist
checklist2.spawn();


// function addCursor(e){
//     e.target.classList.add("horizontal_resize_cursor");
// }