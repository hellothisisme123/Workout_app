# Workout_app
# An app for working out within a website
I took inspiration from millanote.com

To use the color scheme
-go into Workout_app/Workout_App_1.15-active/color_themes/default_theme/Default_theme.acs
-download
-open the .acs file in a text editor
-look at the example comments in the .acs file
-copy their format
-save somwhere you'll be able to have it
-open Index.HTML
-drag and drop the Default_theme.acs over the website from file explorer

do not steal the app and claim it as your own
